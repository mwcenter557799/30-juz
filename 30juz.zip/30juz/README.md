# 30juz

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/maulidin-m/pen/01a0bb43-8b90-709a-9b78-b4ccb2f6f2af](https://codepen.io/editor/maulidin-m/pen/01a0bb43-8b90-709a-9b78-b4ccb2f6f2af).

